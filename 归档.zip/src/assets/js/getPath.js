export default function getUrl (str) {
  let url = 'http://localhost:8000/' + str
  return url
}
