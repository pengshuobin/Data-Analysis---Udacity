<template>
  <div>
   这是第二个页面
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: 'test2',
  data () {
    return {

    }
  }
}
</script>

<style scoped>

</style>
